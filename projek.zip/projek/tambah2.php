<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tambah Data</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="halaman_admin.php">Home</a></li>
            <li><a href="pertandingan.php">Pertandingan</a></li>
            <li><a href="turnamen.php">Jadwal</a></li>
            <li><a href="pendaftaran.php">Data Pendaftaran</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>

<?php
    include 'koneksi.php';

    if(isset($_POST['pertandingan'])){
        $id_pertandingan = $_POST['id_pertandingan'];
        $id_turnamen = $_POST['id_turnamen'];
        $tim_tuan_rumah = $_POST['tim_tuan_rumah'];
        $tim_tamu = $_POST['tim_tamu'];
        $skor_tuan_rumah = $_POST['skor_tuan_rumah'];
        $skor_tamu = $_POST['skor_tamu'];
        $tanggal_pertandingan = $_POST['tanggal_pertandingan'];
        
        // Use prepared statements to prevent SQL injection
        $sql = "INSERT INTO pertandingan (id_pertandingan, id_turnamen, tim_tuan_rumah, tim_tamu, skor_tuan_rumah, skor_tamu, tanggal_pertandingan) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($koneksi, $sql);
        mysqli_stmt_bind_param($stmt, "iisssss", $id_pertandingan, $id_turnamen, $tim_tuan_rumah, $tim_tamu, $skor_tuan_rumah, $skor_tamu, $tanggal_pertandingan);
        
        $result = mysqli_stmt_execute($stmt);

        if(!$result){
            die("Query gagal dijalankan: " . mysqli_stmt_errno($stmt) . " - " . mysqli_stmt_error($stmt));
        } else {
            header("Location: pertandingan.php");
            exit();
        }

        mysqli_stmt_close($stmt);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pertandingan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="css/style3.css">
</head>
<style>
        /* Gaya umum untuk elemen form */
form {
    max-width: 500px;
    margin: 0 auto;
    padding: 30px;
    background: #fff;
    border-radius: 5px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease-in-out;
}

/* Judul Form */
form h2 {
    text-align: center;
    font-size: 24px;
    margin-bottom: 20px;
    color: #333;
}

/* Gaya untuk input field */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="tel"],
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
}

.form-group input[type="text"]:focus,
.form-group input[type="email"]:focus,
.form-group input[type="tel"]:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #007bff;
}

/* Checkbox dan Radio Button */
.checkbox-group,
.radio-group {
    margin-bottom: 20px;
}

.checkbox-group label,
.radio-group label {
    display: block;
    margin-bottom: 5px;
}

.checkbox-group input[type="checkbox"],
.radio-group input[type="radio"] {
    margin-right: 5px;
}

/* Tombol Submit */
button[type="submit"] {
    background: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease-in-out;
}

button[type="submit"]:hover {
    background: #0056b3;
}

/* Efek animasi untuk input ketika diisi */
.form-group input[type="text"]:not(:placeholder-shown),
.form-group input[type="email"]:not(:placeholder-shown),
.form-group input[type="tel"]:not(:placeholder-shown),
.form-group select:not(:placeholder-shown),
.form-group textarea:not(:placeholder-shown) {
    border-color: #4caf50;
}

/* Stil lain yang diperlukan sesuai kebutuhan */

    </style>
<body>
    <div class="content-container">
        <h2>Form Data Pertandingan</h2>
        <!-- Specify the action attribute to the PHP script handling form submission -->
        <form action="" method="POST">
            <div class="form-group">
                <input type="number" class="form-control" name="id_pertandingan" placeholder="id_pertandingan">
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="id_turnamen" placeholder="id_turnamen">              
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="tim_tuan_rumah" placeholder="tim_tuan_rumah">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="tim_tamu" placeholder="tim_tamu">
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="skor_tuan_rumah" placeholder="skor_tuan_rumah">
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="skor_tamu" placeholder="skor_tamu">
            </div>
            <div class="form-group">
                <input type="datetime-local" class="form-control" name="tanggal_pertandingan">
            </div>
            <button name="pertandingan" type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    <script src="js/js.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

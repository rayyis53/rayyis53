<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Jadwal</title>
    <style>
        /* Add some basic styling to the table */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        h2 {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            margin: 0;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ccc;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ccc;
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #808080;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #d3d3d3;
        }

        tr:hover {
            background-color: #ddd;
            transform: scale(1.02); /* Menambahkan efek animasi scaling saat dihover */
        }

        a.button {
            display: inline-block;
            background-color: #333;
            color: #fff;
            padding: 5px 30px;
            text-decoration: none;
            margin: 5px;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Efek transisi warna latar belakang */
        }

        a.button:hover {
            background-color: #555; /* Warna latar belakang saat tombol dihover */
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input[type=text] {
            padding: 10px;
            margin-top: 10px;
            font-size: 17px;
            border: none;
            border-radius: 5px;
        }

        .search-container button {
            padding: 10px;
            margin-top: 10px;
            background: #333;
            font-size: 17px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            color: #fff;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="halaman_admin.php">Home</a></li>
            <li><a href="pertandingan.php">Pertandingan</a></li>
            <li><a href="turnamen.php">Jadwal</a></li>
            <li><a href="pendaftaran.php">Data Pendaftaran</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="content">
        <h2>DATA TURNAMEN</h2>
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" placeholder="Cari turnamen.." name="search">
                <button type="submit">Cari</button>
            </form>
        </div>
        <a class="button" href="tambah.php">TAMBAH TURNAMEN</a>
        <table border="1">
            <tr>
                <th>NO</th>
                <th>ID TURNAMEN</th>
                <th>NAMA_TURNAMEN</th>
                <th>TANGGAL MULAI</th>
                <th>TANGGAL SELESAI</th>
                <th>OPSI</th>
            </tr>
            <?php 
                include 'koneksi.php';
                $no = 1;
                // Memeriksa apakah pencarian telah dilakukan
                if(isset($_GET['search'])) {
                    $search = $_GET['search'];
                    // Query pencarian dengan menggunakan LIKE untuk mencocokkan bagian dari nama turnamen
                    $data = mysqli_query($koneksi, "SELECT * FROM turnamen WHERE nama_turnamen LIKE '%$search%'");
                } else {
                    // Jika tidak ada pencarian, tampilkan semua data turnamen
                    $data = mysqli_query($koneksi, "SELECT * FROM turnamen");
                }
                while($d = mysqli_fetch_array($data)){
            ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $d['id_turnamen']; ?></td>
                <td><?php echo $d['nama_turnamen']; ?></td>
                <td><?php echo $d['tanggal_mulai']; ?></td>
                <td><?php echo $d['tanggal_selesai']; ?></td>
                <td>
                    <a class="button" href="edit.php?id=<?php echo $d['id_turnamen']; ?>">EDIT</a>
                    <a class="button" href="hapus.php?id=<?php echo $d['id_turnamen']; ?>">HAPUS</a>
                </td>
            </tr>
            <?php 
                }
            ?>
        </table>
    </div>
</body>
</html>

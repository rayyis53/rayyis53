
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Pendaftaran Futsal</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="beranda.php">Beranda</a></li>
            <li><a href="#">Jadwal</a></li>
            <li><a href="#">Pendaftaran</a></li>
            <li><a href="#">Kontak</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Beranda</title>
</head>
<body>
    <header class="hero">
        <h1>Selamat Datang di Pendaftaran Futsal</h1>
        <p>Daftar sekarang untuk bergabung dalam turnamen futsal kami.</p>
        <a href="#" class="cta-button">Daftar Sekarang</a>
    </header>

    <section class="features">
        <div class="feature">
            <h2>Turnamen Berkualitas</h2>
            <p>Nikmati pengalaman bermain futsal yang berkualitas dengan pemain-pemain terbaik.</p>
        </div>
        <div class="feature">
            <h2>Infrastruktur Modern</h2>
            <p>Kami memiliki lapangan futsal yang modern dan fasilitas yang lengkap.</p>
        </div>
        <div class="feature">
            <h2>Persaingan Sengit</h2>
            <p>Buktikan kemampuan Anda dalam persaingan sengit dengan tim-tim terbaik.</p>
        </div>
    </section>

    <!-- Konten lainnya untuk beranda Anda -->

    <footer class="footer">
        <p>&copy; 2023 Pendaftaran Futsal. Hak cipta dilindungi.</p>
    </footer>
</body>
</html>

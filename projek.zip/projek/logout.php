<?php
// Mulai sesi jika belum dimulai
session_start();

// Hapus semua variabel sesi
session_unset();

// Hancurkan sesi
session_destroy();

// Alihkan pengguna ke halaman login atau halaman lain yang sesuai
header("Location: halaman_user.php");
exit();
?>

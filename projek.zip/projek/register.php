<?php
session_start();

// Kode untuk koneksi ke database (ganti dengan koneksi yang sesuai)
$localhost = "localhost";
$username = "username";
$password = "password";
$pendaftaran_futsal = "pendaftaran_futsal";

$conn = new mysqli($localhost, $username, $password, $pendaftaran_futsal);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role']; // Pilihan peran (admin atau pengguna)

    // Anda perlu memvalidasi input dan melakukan penanganan kesalahan di sini.

    // Contoh sederhana: Masukkan data ke dalam tabel pengguna
    $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
    
    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "Pendaftaran berhasil.";
        header("Location: login.php");
        exit();
    } else {
        $_SESSION['error'] = "Pendaftaran gagal: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar</title>
</head>
<body>
    <h2>Form Pendaftaran</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required><br>
        <label for="role">Pilih Peran:</label>
        <select name="role" required>
            <option value="admin">Admin</option>
            <option value="user">Pengguna</option>
        </select><br>
        <button type="submit">Daftar</button>
    </form>
    <?php
    if (isset($_SESSION['error'])) {
        echo "<p>{$_SESSION['error']}</p>";
        unset($_SESSION['error']);
    }
    ?>
    <a href="login.php">Sudah punya akun? Masuk di sini.</a>
</body>
</html>

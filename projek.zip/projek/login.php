<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background-image: url('blue.jpg'); /* Ganti 'background.jpg' dengan URL gambar latar belakang Anda */
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
  }
  .login-container {
    width: 300px;
    padding: 20px;
    background-color: rgba(255, 255, 255, 0.9);
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    text-align: center;
    transform: translateZ(0); /* Efek 3D */
    transition: transform 0.3s ease-in-out;
  }
  .login-container:hover {
    transform: scale(1.02); /* Efek hover untuk tampilan 3D */
  }
  h2 {
    color: #333;
  }
  label {
    display: block;
    margin-top: 10px;
  }
  input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  button {
    background-color: #0056b3;
    color: #fff;
    border: none;
    padding: 10px 20px;
    margin-top: 15px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  button:hover {
    background-color: #004188;
  }
  p#error-message {
    color: red;
    font-size: 14px;
  }
</style>
</head>
<body>
  <div class="login-container">
    <h2>Login Panitia</h2>
    <label for="password">Password:</label>
    <input type="password" id="password" placeholder="Enter password">
    <button onclick="login()">Login</button>
    <p id="error-message"></p>
  </div>

  <script>
    function login() {
      var password = document.getElementById("password").value;
      var errorMessage = document.getElementById("error-message");

      if (password === "") {
        errorMessage.textContent = "Please enter a password.";
        return; // Tidak melanjutkan proses login
      }

      // Ganti "yourAdminPassword" dengan kata sandi admin yang Anda inginkan
      if (password === "panitia") {
        errorMessage.textContent = ""; // Menghapus pesan kesalahan jika ada
        alert("Login successful. Welcome Panitia!");
        window.location.href = "halaman_admin.php";
        // Redirect ke halaman admin atau tampilan lain yang sesuai
      } else {
        errorMessage.textContent = "Incorrect password. Please try again.";
      }
    }
  </script>
</body>
</html>
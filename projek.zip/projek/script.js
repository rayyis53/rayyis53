window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.backgroundColor = '#ff5722'; // Ganti warna latar belakang saat scroll
    } else {
        navbar.style.backgroundColor = '#333'; // Kembalikan warna latar belakang ke semula
    }
});




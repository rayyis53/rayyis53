<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Mengubah Data</title>
</head>
<body>
    <nav class="navbar">
        <h1 class="logo">Pendaftaran Futsal</h1>
        <ul class="menu">
            <li><a href="halaman_admin.php">Home</a></li>
            <li><a href="pertandingan.php">Pertandingan</a></li>
            <li><a href="turnamen.php">Jadwal</a></li>
            <li><a href="pendaftaran.php">Data Pendaftaran</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="content">
        <!-- Isi konten situs web Anda -->
    </div>
</body>
</html>
<html lang="en">
<head>
<style>
           /* Gaya umum untuk elemen-elemen formulir */
form {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    transition: all 0.3s ease-in-out;
}

/* Gaya untuk elemen-elemen input */
input[type="text"],
input[type="email"],
input[type="tel"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
}

/* Efek animasi ketika input menerima fokus */
input[type="text"]:focus,
input[type="email"]:focus,
input[type="tel"]:focus {
    border-color: #007bff; /* Ganti warna sesuai keinginan Anda */
}

/* Gaya untuk tombol submit */
button[type="submit"] {
    background: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease-in-out;
}

/* Efek animasi ketika tombol submit diberi hover */
button[type="submit"]:hover {
    background: #0056b3; /* Ganti warna sesuai keinginan Anda */
}

/* Stil lain yang diperlukan sesuai kebutuhan */
</style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Turnamen</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style3.css">
</head>
<body>
    <div class="page-content p-5" id="content">
        <button id="sidebarCollapse" type="button" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4"><i class="fa fa-bars mr-2"></i><small class="text-uppercase font-weight-bold">Menu</small></button>
        <div class="container-fluid">
        <?php
include 'koneksi.php';

if (isset($_POST['ubah_id_turnamen'])) {
    $id = $_POST['ubah_id_turnamen'];
    $Queryid_turnamen = mysqli_real_escape_string($koneksi, $_POST['ubah_id_turnamen']);
    $Querynama_turnamen = mysqli_real_escape_string($koneksi, $_POST['ubah_Nama_turnamen']);
    $Querytanggal_mulai = mysqli_real_escape_string($koneksi, $_POST['ubah_tanggal_mulai']);
    $Querytanggal_selesai = mysqli_real_escape_string($koneksi, $_POST['ubah_tanggal_selesai']);

    $query = "UPDATE turnamen SET id_turnamen='$Queryid_turnamen', nama_turnamen='$Querynama_turnamen', tanggal_mulai='$Querytanggal_mulai', tanggal_selesai='$Querytanggal_selesai' WHERE id_turnamen='$id'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Gagal Di Ubah " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
    } else {
        header('Location: turnamen.php');
        exit();
    }
}

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM turnamen WHERE id_turnamen='$id'");
while ($tampil = mysqli_fetch_array($data)) {
    ?>
    <form method="post" action="">
        <div class="mb-3">
            <label class="form-label">ID Turnamen</label>
            <input name="ubah_id_turnamen" type="number" class="form-control" value="<?php echo $tampil["id_turnamen"]; ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Nama Turnamen</label>
            <input name="ubah_Nama_turnamen" type="text" class="form-control" value="<?php echo $tampil["nama_turnamen"]; ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Tanggal Mulai</label>
            <input name="ubah_tanggal_mulai" type="datetime-local" class="form-control" value="<?php echo date("Y-m-d\TH:i:s", strtotime($tampil["tanggal_mulai"])); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Tanggal Selesai</label>
            <input name="ubah_tanggal_selesai" type="datetime-local" class="form-control" value="<?php echo date("Y-m-d\TH:i:s", strtotime($tampil["tanggal_selesai"])); ?>">
        </div>
        <html>
            <body>
                <button type="submit" onclick="return confirm('Apakah Anda Yakin Ingin Mengedit Data?')">Simpan</button>
            </body>
        </html>
    </form>
<?php } ?>

        </div>
        <script src="js/js.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </div>
</body>
</html>
